# Cosmic Tweaks — Fabric 1.21.11

Expanded starter implementation of a client-side QoL/HUD mod.

Included:
- Cosmic Tweaks GUI opened with Right Shift
- Main-menu Cosmic Tweaks button
- HUD with FPS, ping, coordinates and clock
- Keystrokes display
- CPS display placeholder
- Zoom keybind (C) state
- Fullbright toggle state (G)
- HUD settings screen
- Visual settings screen
- Performance/Cosmetics placeholder screens
- Blue/black/purple cosmic UI direction
- No combat automation or hacked-client features

Minecraft 1.21.11 is an obfuscated release, so this project uses remapping Loom as required for that release.

Build with Java 21 and Gradle:
  ./gradlew build

The end-user JAR is produced under build/libs after a successful build.
