package com.cosmictweaks.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class VisualSettingsScreen extends Screen {
    private final Screen parent;
    public VisualSettingsScreen(Screen parent) { super(Component.literal("Visuals")); this.parent = parent; }

    @Override protected void init() {
        int cx = width / 2, y = height / 2 - 70;
        addRenderableWidget(Button.builder(Component.literal("Zoom: C"), b -> {})
                .bounds(cx - 150, y, 300, 26).build());
        addRenderableWidget(Button.builder(Component.literal("Fullbright: G"), b -> ModState.fullbright = !ModState.fullbright)
                .bounds(cx - 150, y + 34, 300, 26).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(cx - 70, y + 82, 140, 26).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float d) {
        renderBackground(g, mx, my, d);
        g.drawCenteredString(font, "COSMIC TWEAKS • VISUALS", width / 2, height / 2 - 110, 0xFFEAF6FF);
        super.render(g, mx, my, d);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
