package com.cosmictweaks.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class InfoScreen extends Screen {
    private final Screen parent;
    private final String title;
    public InfoScreen(Screen parent, String title) { super(Component.literal(title)); this.parent = parent; this.title = title; }

    @Override protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(width / 2 - 70, height / 2 + 55, 140, 26).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float d) {
        renderBackground(g, mx, my, d);
        g.drawCenteredString(font, "COSMIC TWEAKS • " + title.toUpperCase(), width / 2, height / 2 - 55, 0xFFEAF6FF);
        g.drawCenteredString(font, "More modules are ready to be added here.", width / 2, height / 2 - 32, 0xFF86BFFF);
        super.render(g, mx, my, d);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
