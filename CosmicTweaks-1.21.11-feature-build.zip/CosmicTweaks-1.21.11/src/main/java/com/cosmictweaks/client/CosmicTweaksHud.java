package com.cosmictweaks.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class CosmicTweaksHud {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static int frames;
    private static long lastFpsTime = System.currentTimeMillis();
    private static int fps;

    public static final HudElement RENDERER = CosmicTweaksHud::render;

    private CosmicTweaksHud() {}

    public static void render(GuiGraphics g, net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        frames++;
        long now = System.currentTimeMillis();
        if (now - lastFpsTime >= 1000) {
            fps = frames;
            frames = 0;
            lastFpsTime = now;
        }

        int x = 8, y = 8;
        g.fill(x - 4, y - 4, x + 155, y + 90, 0xB9080D18);
        g.fill(x - 4, y - 4, x + 155, y - 2, 0xFF65B9FF);
        int line = 0;

        if (ModState.showFps) {
            text(g, "FPS  " + fps, x, y + line++ * 12);
        }
        if (ModState.showPing && mc.player != null) {
            int ping = 0;
            if (mc.getConnection() != null && mc.player != null) {
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) ping = info.getLatency();
            }
            text(g, "PING  " + ping + " ms", x, y + line++ * 12);
        }
        LocalPlayer p = mc.player;
        if (ModState.showCoords && p != null) {
            text(g, String.format("XYZ  %.0f  %.0f  %.0f", p.getX(), p.getY(), p.getZ()),
                    x, y + line++ * 12);
        }
        if (ModState.showClock) {
            text(g, "TIME  " + LocalTime.now().format(CLOCK), x, y + line++ * 12);
        }

        int bottom = mc.getWindow().getGuiScaledHeight() - 52;
        if (ModState.showKeystrokes) {
            drawKey(g, "W", 34, bottom);
            drawKey(g, "A", 10, bottom + 24);
            drawKey(g, "S", 34, bottom + 24);
            drawKey(g, "D", 58, bottom + 24);
        }
        if (ModState.showCps) {
            text(g, "CPS  --", 10, bottom + 54);
        }
    }

    private static void drawKey(GuiGraphics g, String key, int x, int y) {
        g.fill(x, y, x + 20, y + 20, 0xCC101A2A);
        g.fill(x, y, x + 20, y + 2, 0xFF65B9FF);
        g.drawCenteredString(Minecraft.getInstance().font, key, x + 10, y + 6, 0xFFEAF6FF);
    }

    private static void text(GuiGraphics g, String s, int x, int y) {
        g.drawString(Minecraft.getInstance().font, Component.literal(s), x, y, 0xFFEAF6FF, true);
    }
}
