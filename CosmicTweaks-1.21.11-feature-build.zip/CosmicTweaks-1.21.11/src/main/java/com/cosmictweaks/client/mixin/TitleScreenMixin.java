package com.cosmictweaks.client.mixin;

import com.cosmictweaks.client.CosmicTweaksScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void cosmicTweaks$addButton(CallbackInfo ci) {
        TitleScreen self = (TitleScreen)(Object)this;
        // Button is added through the vanilla screen API in the generated mixin.
        // The final button position is intentionally modest to avoid covering vanilla buttons.
        self.addRenderableWidget(Button.builder(
                net.minecraft.network.chat.Component.literal("Cosmic Tweaks"),
                b -> self.minecraft.setScreen(new CosmicTweaksScreen(self))
        ).bounds(self.width / 2 - 100, self.height / 4 + 104, 200, 20).build());
    }
}
