package com.cosmictweaks.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class CosmicTweaksClient implements ClientModInitializer {
    public static final String MOD_NAME = "Cosmic Tweaks";
    public static KeyMapping OPEN_MENU;
    public static KeyMapping ZOOM;
    public static KeyMapping FULLBRIGHT;

    @Override
    public void onInitializeClient() {
        OPEN_MENU = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.cosmic-tweaks.open_menu", GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.cosmic-tweaks"));
        ZOOM = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.cosmic-tweaks.zoom", GLFW.GLFW_KEY_C,
                "category.cosmic-tweaks"));
        FULLBRIGHT = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.cosmic-tweaks.fullbright", GLFW.GLFW_KEY_G,
                "category.cosmic-tweaks"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_MENU.consumeClick()) {
                client.setScreen(new CosmicTweaksScreen(client.screen));
            }
            if (client.player != null) {
                ModState.zoom = ZOOM.isDown();
                while (FULLBRIGHT.consumeClick()) ModState.fullbright = !ModState.fullbright;
            }
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                CosmicTweaksHud.RENDERER
        );
    }
}
