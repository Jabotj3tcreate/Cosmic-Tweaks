package com.cosmictweaks.client;

public final class ModState {
    public static boolean showFps = true;
    public static boolean showPing = true;
    public static boolean showCoords = true;
    public static boolean showKeystrokes = true;
    public static boolean showCps = true;
    public static boolean showArmor = true;
    public static boolean showPotionEffects = true;
    public static boolean zoom = false;
    public static boolean fullbright = false;
    public static boolean showClock = true;

    private ModState() {}
}
