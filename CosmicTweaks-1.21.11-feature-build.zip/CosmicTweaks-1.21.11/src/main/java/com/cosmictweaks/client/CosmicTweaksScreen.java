package com.cosmictweaks.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CosmicTweaksScreen extends Screen {
    private final Screen parent;

    public CosmicTweaksScreen(Screen parent) {
        super(Component.literal("Cosmic Tweaks"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int top = height / 2 - 100;

        addRenderableWidget(Button.builder(label("HUD"), b -> open(new HudSettingsScreen(this)))
                .bounds(cx - 155, top, 145, 26).build());
        addRenderableWidget(Button.builder(label("Visuals"), b -> open(new VisualSettingsScreen(this)))
                .bounds(cx + 10, top, 145, 26).build());
        addRenderableWidget(Button.builder(label("Performance"), b -> open(new InfoScreen(this, "Performance")))
                .bounds(cx - 155, top + 38, 145, 26).build());
        addRenderableWidget(Button.builder(label("Cosmetics"), b -> open(new InfoScreen(this, "Cosmetics")))
                .bounds(cx + 10, top + 38, 145, 26).build());
        addRenderableWidget(Button.builder(label("Close"), b -> onClose())
                .bounds(cx - 70, top + 112, 140, 26).build());
    }

    private void open(Screen s) { minecraft.setScreen(s); }
    private static Component label(String s) { return Component.literal(s); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int l = width / 2 - 185, r = width / 2 + 185, t = height / 2 - 135, b = height / 2 + 145;
        g.fill(l, t, r, b, 0xF0080D18);
        g.fill(l, t, r, t + 3, 0xFF65B9FF);
        g.drawCenteredString(font, "COSMIC TWEAKS", width / 2, t + 20, 0xFFEAF6FF);
        g.drawCenteredString(font, "CLIENT-SIDE  •  QOL  •  1.21.11", width / 2, t + 39, 0xFF86BFFF);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
