package com.cosmictweaks.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class HudSettingsScreen extends Screen {
    private final Screen parent;
    public HudSettingsScreen(Screen parent) { super(Component.literal("HUD")); this.parent = parent; }

    @Override protected void init() {
        int cx = width / 2, y = height / 2 - 110;
        add(cx - 150, y, "FPS", () -> ModState.showFps = !ModState.showFps);
        add(cx + 10, y, "Ping", () -> ModState.showPing = !ModState.showPing);
        add(cx - 150, y + 32, "Coordinates", () -> ModState.showCoords = !ModState.showCoords);
        add(cx + 10, y + 32, "Keystrokes", () -> ModState.showKeystrokes = !ModState.showKeystrokes);
        add(cx - 150, y + 64, "CPS", () -> ModState.showCps = !ModState.showCps);
        add(cx + 10, y + 64, "Clock", () -> ModState.showClock = !ModState.showClock);
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(cx - 70, y + 120, 140, 26).build());
    }

    private void add(int x, int y, String name, Runnable r) {
        addRenderableWidget(Button.builder(Component.literal(name), b -> r.run())
                .bounds(x, y, 140, 26).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float d) {
        renderBackground(g, mx, my, d);
        g.drawCenteredString(font, "COSMIC TWEAKS • HUD", width / 2, height / 2 - 140, 0xFFEAF6FF);
        g.drawCenteredString(font, "Click a module to toggle it", width / 2, height / 2 - 124, 0xFF86BFFF);
        super.render(g, mx, my, d);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
